package Database_Testing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class JDBC_Example1 {

	public static void main(String[] args) throws SQLException {
		
		// step1    Create connection
		Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/pdborc1","hr","hr");
		
		// step 2    Create statement
		Statement stmt = con.createStatement();
		
		// step 3    Excute statement
		String s = "insert into users values(102,'mercury2','mercury2')";     // inserting values
		String s1 = "update users set uname='mer2' where userid=102";         // updating values
		String s2 = "dalete users where userid=102";                          // deleting values
		
		stmt.executeQuery(s);
		
		
		// step 4     Close connection
		con.close();
		
		System.out.println("program is exited");
		
		
	}

}
