package Database_Testing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JDBC_Example2 {

	public static void main(String[] args) throws SQLException {
		
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/newtours/index.php");	
		driver.manage().window().maximize();
		
		
		// step1    Create connection
		Connection con =DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521/pdborc1","hr","hr");
				
		// step 2    Create statement
		Statement stmt = con.createStatement();
				
		// step 3    Excute statement
		String s = "select uname,passwrd from users"; 
		ResultSet rs = stmt.executeQuery(s);
				
		while(rs.next())
		{
			String username = rs.getString("uname");
			String password = rs.getString("passwrd");
					
			driver.findElement(By.xpath("//input[@type='text']")).sendKeys(username);
			driver.findElement(By.xpath("//input[@type='password']")).sendKeys(password);
			driver.findElement(By.xpath("//input[@type='submit']")).click();
			
			if(driver.getTitle().equals("Find a Flight: Mercury Tours"))
			{
				System.out.println("Test case passed");
			}
			else
			{
				System.out.println("Test case failed");
			}
			driver.findElement(By.xpath("//a[@style='margin-left: 5px;color: #0000ee;text-decoration: underline;']")).click();
		}
				
		// step 4     Close connection
		con.close();
			
		System.out.println("program is exited");
	

	}

}
