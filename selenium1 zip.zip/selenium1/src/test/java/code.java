import org.apache.commons.codec.binary.Base64;

public class code {

	public static void main(String[] args) {
	
		String str="1234iliaz@";
		byte[] encodedstring = Base64.encodeBase64(str.getBytes());
		System.out.println("Encoded String is : "+new String(encodedstring));
		byte[] decodestring  = Base64.decodeBase64(encodedstring);
		System.out.println("decoded string is : "+new String(decodestring));
		

	}

}
