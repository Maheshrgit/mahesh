import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Gmail_Login {

	public static void main(String[] args) {


		
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		driver.findElement(By.xpath("//input[@name='email']")).sendKeys("shaikiliyaz112@gmail.com");
		
		
		driver.findElement(By.xpath("//input[@name='pass']")).sendKeys("1234567789");
		driver.findElement(By.xpath("//button[@name='login']")).click();
		

	}

}
