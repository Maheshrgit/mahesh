package Encode_Decode;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Testcase_with_EncryptedPassword {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.nopcommerce.com/en/login");
		
		WebElement My = driver.findElement(By.xpath("//a[@class='userlink']"));
		WebElement Login = driver.findElement(By.xpath("//a[@class='ico-login']"));
		Actions act=new Actions(driver);
		act.moveToElement(My).build().perform();
		act.moveToElement(Login).click().build().perform();
		
		driver.findElement(By.xpath("//input[@class='username']")).sendKeys("shaikiliaz1234@gmail.com");
		driver.findElement(By.xpath("//input[@class='password']")).sendKeys(decodedString("dGVzdDEyMw=="));
		
		driver.findElement(By.xpath("//input[@class='btn blue-button']")).click();
	
	}
	
	static String decodedString(String password)
	{
		byte[] decodedString = Base64.decodeBase64(password);
		return(new String(decodedString));
	}

}
