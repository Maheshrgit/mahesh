package Encode_Decode;

import org.apache.commons.codec.binary.Base64;

public class fb_password {

	
	public static void main(String[] args) {
		
		String str = "1234iliaz@";
		byte[] encodedString = Base64.encodeBase64(str.getBytes());
		System.out.println("encoded string: "+new String(encodedString));
		
		
	}
}
