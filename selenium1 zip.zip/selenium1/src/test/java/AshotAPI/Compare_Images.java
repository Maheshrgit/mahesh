package AshotAPI;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.comparison.ImageDiff;
import ru.yandex.qatools.ashot.comparison.ImageDiffer;

public class Compare_Images {

	public static void main(String[] args) throws IOException {
	
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");	
		driver.manage().window().maximize();
		
		BufferedImage expectedImage = ImageIO.read(new File("C:\\Users\\shaik\\OneDrive\\Pictures\\Saved Pictures\\OrangegrmLogo.png"));
		
		WebElement Logoimage = driver.findElement(By.xpath("//div[@id='divLogo']"));
		Screenshot logoImageScreenshot = new AShot().takeScreenshot(driver, Logoimage);
		BufferedImage actualImage = logoImageScreenshot.getImage();
		
		ImageDiffer imgdiff = new ImageDiffer();
		ImageDiff diff =imgdiff.makeDiff(actualImage, expectedImage); 
		
		if(diff.hasDiff()==true)  // this will compare two images
		{
			System.out.println("Images are not same");
		}
		else
		{
			System.out.println("Images are  same");
		}
		
		driver.quit();

	}

}
