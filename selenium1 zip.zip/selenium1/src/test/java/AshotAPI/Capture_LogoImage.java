package AshotAPI;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

public class Capture_LogoImage {

	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");	
		driver.manage().window().maximize();
		
		WebElement Logoimagge = driver.findElement(By.xpath("//div[@id='divLogo']//following::img"));
		
		
		Screenshot logoImageScreenshot = new AShot().takeScreenshot(driver, Logoimagge);
		ImageIO.write(logoImageScreenshot.getImage(), "png", new File("C:\\Users\\shaik\\OneDrive\\Pictures\\Saved Pictures\\OrangegrmLogo.png"));
		
		File f=new File("C:\\\\Users\\\\shaik\\\\OneDrive\\\\Pictures\\\\Saved Pictures\\\\OrangegrmLogo.png");
		
		if(f.exists())
		{
			System.out.println("Image Fiile Captured");
		}
		else
		{
			System.out.println("Image Fiile not Captured");
		}
	}

}
