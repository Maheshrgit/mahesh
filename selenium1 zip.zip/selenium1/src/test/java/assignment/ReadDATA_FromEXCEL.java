package assignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDATA_FromEXCEL {

	public static void main(String[] args) throws IOException {
		
		FileInputStream file = new FileInputStream("C:\\Users\\shaik\\OneDrive\\Documents\\data 1.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("sheet1");  // provide sheet name
		int rowcount = sheet.getLastRowNum();             // returns the last row number
		int colcount = sheet.getRow(0).getLastCellNum();            // returns last cell number
		
		for(int i=1;i<rowcount;i++)
		{
			XSSFRow current_row=sheet.getRow(i);      // focused on current row
			
			for(int j=0;j<colcount;j++)
			{
				String value = current_row.getCell(j).toString();
				System.out.print("  "+value+"  ");
			}
			System.out.println();
		}
		
		

	}

}
