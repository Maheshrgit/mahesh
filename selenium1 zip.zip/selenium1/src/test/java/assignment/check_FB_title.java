package assignment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class check_FB_title {

	public static void main(String[] args) throws InterruptedException {
System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		String expct_title = "Facebook";
		driver.manage().window().maximize();
		String actual_title = driver.getTitle();
		System.out.println(actual_title);
		Thread.sleep(2000);
		if(expct_title.equals(actual_title))
		{
			System.out.println("test is passed");
		}
		else
		{
			System.out.println("test is failed");
		}
		driver.close();

	}

}
