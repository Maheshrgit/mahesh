package webdriver_commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Get_commands {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/newtours/");  //opens the URL
		System.out.println(driver.getTitle());          //get the Title of the page
		System.out.println(driver.getCurrentUrl());     // returns the current page URL
		String text=driver.findElement(By.xpath("//b[text()='Jul 6, 2017']")).getText();  // get the text
		System.out.println(text);
		driver.close();
		
	}

}
