package webdriver_commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Conditional_commands {

	public static void main(String[] args) throws InterruptedException {
	
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://online.apsrtcpass.in/counterstupass.do");
		WebElement name = driver.findElement(By.xpath("//input[@id='userProperties(sscpassfailyr)']"));
		if(name.isDisplayed() && name.isEnabled())
		{
			name.sendKeys("2013");
		}
		else
		{
			System.out.println("webelement is not displayed/enabled");
		}
        Thread.sleep(2000);
		System.out.println(driver.findElement(By.xpath("//input[@id='gender1']")).isSelected());
		System.out.println(driver.findElement(By.xpath("//input[@id='gender2']")).isSelected());
				
		if(driver.findElement(By.xpath("//input[@id='gender2']")).isSelected()==false)
		{
			Thread.sleep(2000);
		driver.findElement(By.xpath("//input[@id='gender2']")).click();
		}
		Thread.sleep(2000);
		driver.close();
	
	}

}
