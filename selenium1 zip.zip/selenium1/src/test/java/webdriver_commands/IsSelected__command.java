package webdriver_commands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class IsSelected__command {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://online.apsrtcpass.in/counterstupass.do");
		// female
		System.out.println(driver.findElement(By.xpath("//input[@id='gender1']")).isSelected());
		// male
		System.out.println(driver.findElement(By.xpath("//input[@id='gender2']")).isSelected());
		
		if(driver.findElement(By.xpath("//input[@id='gender1']")).isSelected()==false)
		{
			Thread.sleep(2000);
			driver.findElement(By.xpath("//input[@id='gender1']")).click();
		}
		Thread.sleep(2000);
		driver.close();

	}

}
