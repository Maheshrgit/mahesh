package Robot_API;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class RobotAPI_Demo {

	public static void main(String[] args) throws AWTException, InterruptedException {
	

		System.setProperty("webdriver.gecko.driver","C:\\work\\geckodriver.exe");
		WebDriver driver = new FirefoxDriver();
		driver.get("http://spreadsheetpage.com/index.php/site/file/yearly_calender_workbook");
		
		driver.findElement(By.xpath(" ")).click();
		Robot robot = new Robot();
		
		robot.keyPress(KeyEvent.VK_DOWN);
		Thread.sleep(2000);	
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		robot.keyPress(KeyEvent.VK_TAB);
		
		robot.keyPress(KeyEvent.VK_ENTER);
		

	}

}
