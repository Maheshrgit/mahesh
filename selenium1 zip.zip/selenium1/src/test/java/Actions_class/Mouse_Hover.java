package Actions_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Mouse_Hover {

	public static void main(String[] args) throws InterruptedException {

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/leave/viewLeaveList");
		WebElement user = driver.findElement(By.xpath("//input[@id='txtUsername']"));
		user.sendKeys("Admin");
		WebElement pass = driver.findElement(By.xpath("//input[@id='txtPassword']"));
		pass.sendKeys("admin123");
		WebElement login = driver.findElement(By.xpath("//input[@id='btnLogin']"));
		login.click();
		
		WebElement Admin = driver.findElement(By.xpath("//b[text()='Admin']"));
		WebElement Usrmg = driver.findElement(By.xpath("//a[@id='menu_admin_UserManagement']"));
		WebElement Users = driver.findElement(By.xpath("//a[@id='menu_admin_viewSystemUsers']"));
		
		Actions act = new Actions(driver);
		
		/*
		act.moveToElement(Admin).build().perform();
		act.moveToElement(Usrmg).build().perform();
		act.moveToElement(Users).click().build().perform();
		
		*/
		act.moveToElement(Admin).moveToElement(Usrmg).moveToElement(Users).click().build().perform();
		
		Thread.sleep(2000);
		driver.close();
	}

}
