package Basic_Programs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Close_method {


	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		
		WebDriver driver1 = new ChromeDriver();
		WebDriver driver2 = new ChromeDriver();
		driver1.get("https://www.apsrtconline.in/oprs-web/");
		driver2.get("https://www.flipkart.com/");
		Thread.sleep(2000);
		driver2.close();

	}
}
