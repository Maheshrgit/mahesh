package Basic_Programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Alerts {


	public static void main(String[] args) throws InterruptedException {
		

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
	
	 Read_text();
	// Ok_button();
	// Cancel_button();
	}
	
	public static void Ok_button() throws InterruptedException
	{
		
	WebDriver driver = new ChromeDriver();
	driver.get("https://demo.guru99.com/test/delete_customer.php");
	WebElement userID = driver.findElement(By.xpath("//input[@name='cusid']"));
	userID.sendKeys("8790549627");
	WebElement submit = driver.findElement(By.xpath("//input[@name='submit']"));
	submit.click();
	 Thread.sleep(2000);
	driver.switchTo().alert().accept();
	driver.switchTo().alert().accept();
    Thread.sleep(2000);
	driver.close();
}
		
	public static void Cancel_button() throws InterruptedException
	{
		
	WebDriver driver = new ChromeDriver();
	driver.get("https://demo.guru99.com/test/delete_customer.php");
	WebElement userID = driver.findElement(By.xpath("//input[@name='cusid']"));
	userID.sendKeys("8790549627");
	WebElement submit = driver.findElement(By.xpath("//input[@name='submit']"));
	submit.click();
	 Thread.sleep(2000);
    driver.switchTo().alert().dismiss();
    Thread.sleep(2000);
	driver.close();
	}

	public static void Read_text() throws InterruptedException
	{
		
	WebDriver driver = new ChromeDriver();
	driver.get("https://demo.guru99.com/test/delete_customer.php");
	WebElement userID = driver.findElement(By.xpath("//input[@name='cusid']"));
	userID.sendKeys("8790549627");
	WebElement submit = driver.findElement(By.xpath("//input[@name='submit']"));
	submit.click();
	 driver.switchTo().alert().accept();
	 String Actual_msg = driver.switchTo().alert().getText();
	 System.out.println(Actual_msg);
	 String Expected_msg = "Customer succesfully deleted";
	 if(Actual_msg.equals(Expected_msg))
	 {
		 System.out.println("test case is passed");
	 }
	 else
	 {
		 System.out.println("test case is failed");
	 }
	driver.close();
	}
}
