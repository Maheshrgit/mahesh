package TestCases;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ISelect;
import org.openqa.selenium.support.ui.Select;

public class Calculation_test {

	public static void main(String[] args) throws IOException {
	

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.moneycontrol.com/fixed-income/calculator/state-bank-of-india-sbi/fixed-deposit-calculator-SBI-BSB001.html");
		driver.manage().window().maximize();
		FileInputStream file = new FileInputStream("C:\\Users\\shaik\\OneDrive\\Documents\\cal.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("sheet1");  // provide sheet name
		int rowcount = sheet.getLastRowNum();
		
		
		System.out.println(rowcount);
		
		for(int i=1;i<=rowcount;i++)
		{
			XSSFRow row = sheet.getRow(i);
			
			
			
			XSSFCell principlecell = row.getCell(0);
			int princ = (int)principlecell.getNumericCellValue();
			
			XSSFCell rateofinterest = row.getCell(1);
			int roi = (int)rateofinterest.getNumericCellValue();
			
			XSSFCell period = row.getCell(2);
			int per = (int)period.getNumericCellValue();
			
			XSSFCell frequency = row.getCell(3);
			int freq = (int)frequency.getNumericCellValue();
			
			XSSFCell Maturityvalue = row.getCell(4);
			int exp_value = (int)Maturityvalue.getNumericCellValue();
			
			driver.findElement(By.xpath("//input[@id='principal']")).sendKeys(String.valueOf(princ));
			driver.findElement(By.xpath("//input[@id='interest']")).sendKeys(String.valueOf(roi));
			driver.findElement(By.xpath("//input[@id='tenure']")).sendKeys(String.valueOf(per));
			
			Select per_type = new Select(driver.findElement(By.xpath("//select[@id='tenurePeriod']")));
			per_type.selectByVisibleText("year(s)");
			
			Select freq_type = new Select(driver.findElement(By.xpath("//select[@id='frequency']")));
			freq_type.selectByValue("0");
			
			driver.findElement(By.xpath("//img[@src='https://images.moneycontrol.com/images/mf_revamp/btn_calcutate.gif']")).click();
			
			String Actual_value = driver.findElement(By.xpath("//span[@ID='resp_matval']")).getText();
			
			if(Actual_value.equals(exp_value))
			{
				System.out.println("Test Passed");
			}
			else
			{
				System.out.println("Test Failed");
			}
			
	
			}
	}
}

