package TestCases;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Registration_test {

	public static void main(String[] args) throws IOException, InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://demo.guru99.com/test/newtours/");
		driver.manage().window().maximize();
		FileInputStream file = new FileInputStream("C:\\Users\\shaik\\OneDrive\\Documents\\registration.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("sheet1");  // provide sheet name
		int rowcount = sheet.getLastRowNum();
		System.out.println("No of records in the Excel sheet : "+rowcount);
		
		
		for(int row=1;row<rowcount;row++)
		{
			XSSFRow current_row = sheet.getRow(row);
			
			String Firstname = current_row.getCell(0).toString();
			String Lastname = current_row.getCell(1).toString();
			String Phone = current_row.getCell(2).toString();
			String Email = current_row.getCell(3).toString();
			String Address = current_row.getCell(4).toString();
			String City = current_row.getCell(5).toString();
			String State = current_row.getCell(6).toString();
			String Postal_code = current_row.getCell(7).toString();
			String Country = current_row.getCell(8).toString();
			String Username = current_row.getCell(9).toString();
			String Password = current_row.getCell(10).toString();
			String Confirm_Password = current_row.getCell(11).toString();
			
			driver.findElement(By.linkText("REGISTER")).click();
			
			driver.findElement(By.name("firstName")).sendKeys(Firstname);
			driver.findElement(By.name("lastName")).sendKeys(Lastname);
			driver.findElement(By.name("phone")).sendKeys(Phone);
			driver.findElement(By.name("userName")).sendKeys(Email);
			driver.findElement(By.name("address1")).sendKeys(Address);
			driver.findElement(By.name("city")).sendKeys(City);
			driver.findElement(By.name("state")).sendKeys(State);
			driver.findElement(By.name("postalCode")).sendKeys(Postal_code);
		
			
			Select drop_country = new Select(driver.findElement(By.xpath("//select[@name='country']")));
			drop_country.selectByVisibleText(Country);
			
			driver.findElement(By.name("email")).sendKeys(Username);
			driver.findElement(By.name("password")).sendKeys(Password);
			driver.findElement(By.name("confirmPassword")).sendKeys(Confirm_Password);
			
			driver.findElement(By.name("submit")).click();
			
			if(driver.getPageSource().contains("Thank you for registering"))
			{
			System.out.println("Registration completed for  "+row+" record");
		}
		else
		{
			System.out.println("Registration failed for "+row+" record");

		}
			Thread.sleep(2000);
			
		}
		driver.close();
	}

}
