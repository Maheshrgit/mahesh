package Encode_Decode;

import org.apache.commons.codec.binary.Base64;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Testcase_with_EncryptedPassword {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
	
	//	driver.findElement(By.xpath("//input[@type='text']")).sendKeys("shaikiliaz1234@gmail.com");
		driver.findElement(By.xpath("//input[@type='password']")).sendKeys(decodedString("MTIzNGlsaWF6QA=="));
		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
	
	}
	
	static String decodedString(String password)
	{
		byte[] decodedString = Base64.decodeBase64(password);
		return(new String(decodedString));
	}

}
