package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Calender {
	
	@Test

	public static void main(String[] args) {
		
		leave_form();
	}
	
	public static void leave_form()
	{
	
		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/leave/viewLeaveList");
		WebElement user = driver.findElement(By.xpath("//input[@id='txtUsername']"));
		user.sendKeys("Admin");
		WebElement pass = driver.findElement(By.xpath("//input[@id='txtPassword']"));
		pass.sendKeys("admin123");
		WebElement login = driver.findElement(By.xpath("//input[@id='btnLogin']"));
		login.click();
		
		WebElement Leave = driver.findElement(By.xpath("//a[@id='menu_leave_viewLeaveModule']"));
		Leave.click();
		WebElement Assignleave = driver.findElement(By.xpath("//a[@id='menu_leave_assignLeave']"));
		Assignleave.click();
		WebElement Empname = driver.findElement(By.xpath("//input[@name='assignleave[txtEmployee][empName]']"));
		Empname.sendKeys("SHAIK ILIAZ");
		WebElement reason = driver.findElement(By.xpath("//select[@id='assignleave_txtLeaveType']"));
		Select sc = new Select(reason);
		sc.selectByVisibleText("CAN - Personal");
		WebElement from = driver.findElement(By.xpath("//input[@id='assignleave_txtFromDate']"));
		from.click();
		Select year = new Select(driver.findElement(By.xpath("//select[@class='ui-datepicker-year']")));
		year.selectByVisibleText("2022");
		Select month = new Select(driver.findElement(By.xpath("//select[@class='ui-datepicker-month']")));
		month.selectByVisibleText("Mar");
		WebElement date = driver.findElement(By.xpath("//table[@class='ui-datepicker-calendar']//tr[1]//td[7]"));
		date.click();
		
		WebElement Duration = driver.findElement(By.xpath("//select[@id='assignleave_duration_duration']"));
		Select sc1 = new Select(Duration);
		sc1.selectByVisibleText("Full Day");
		WebElement Comments = driver.findElement(By.xpath("//textarea[@id='assignleave_txtComment']"));
		Comments.sendKeys("Going to a Family trip");

	}

}
