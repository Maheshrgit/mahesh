package TestCases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class webTable {
	
	//@Test

	public  void main() {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://opensource-demo.orangehrmlive.com/");
		WebElement user = driver.findElement(By.xpath("//input[@id='txtUsername']"));
		user.sendKeys("Admin");
		WebElement pass = driver.findElement(By.xpath("//input[@id='txtPassword']"));
		pass.sendKeys("admin123");
		WebElement login = driver.findElement(By.xpath("//input[@id='btnLogin']"));
		login.click();
		
		
		WebElement Admin = driver.findElement(By.xpath("//b[text()='Admin']"));
		Admin.click();
		WebElement Usrmg = driver.findElement(By.xpath("//a[@id='menu_admin_UserManagement']"));
		Usrmg.click();
		WebElement Users = driver.findElement(By.xpath("//a[@id='menu_admin_viewSystemUsers']"));
		Users.click();
		
		int rows = driver.findElements(By.xpath("//table[@class='table hover']//tr")).size();
		System.out.println(rows);
		int statuscount=0;
		
		for(int i=1;i<rows;i++)
		{
			String status = driver.findElement(By.xpath("//table[@class='table hover']//tr["+i+"]//td[5]")).getText();
			
			if(status.equals("Enabled"))
			{
				statuscount=statuscount+1;
			}
		}
		System.out.println("No of employees Enabled: "+statuscount);
		driver.close();		
	}

}
