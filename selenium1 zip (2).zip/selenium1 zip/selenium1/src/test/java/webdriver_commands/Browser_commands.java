package webdriver_commands;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Browser_commands {

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		driver.close(); // closes the current window
		driver.quit();  // closes all the windows

	}

}
