package Basic_Programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Actions_class {


	public static void main(String[] args) {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
	//	 RightClick();  //---contextClick();
	//	DoubleClick();  //---DoubleClick();
	//	Hover();        //---moveTOElement();
		// drag_and_drop();   //---dragAndDrop();
	}
	
	
	private static void drag_and_drop() {
		WebDriver driver = new ChromeDriver();
		Actions ac1=new Actions(driver);
		driver.manage().window().maximize();
		driver.get("https://testautomationpractice.blogspot.com/");
		WebElement from = driver.findElement(By.xpath("//div[@id='draggable']"));
       WebElement to = driver.findElement(By.xpath("//div[@id='droppable']"));		
		ac1.dragAndDrop(from, to).build().perform();
		
	}
	public static void Hover()
	{
	WebDriver driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://testautomationpractice.blogspot.com/");
	WebElement age = driver.findElement(By.xpath("//input[@id='age']"));
	Actions ac = new Actions(driver);
	ac.moveToElement(age).build().perform();
	}
	public static void DoubleClick()
	{
	WebDriver driver = new ChromeDriver();
	Actions ac=new Actions(driver);
	driver.manage().window().maximize();
	driver.get("https://testautomationpractice.blogspot.com/");
	WebElement tagsTextBox = driver.findElement(By.xpath("//button[@ondblclick='myFunction1()']"));
	ac.doubleClick(tagsTextBox).build().perform();
	
	
	}
	
	public static void RightClick()
	{
	WebDriver driver = new ChromeDriver();
	Actions ac=new Actions(driver);
	driver.manage().window().maximize();
	driver.get("https://testautomationpractice.blogspot.com/");
	WebElement username = driver.findElement(By.xpath("//input[@id='field2']"));
	ac.contextClick(username).build().perform();
	
	
	
	}
}