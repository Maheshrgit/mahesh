package Basic_Programs;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Verify_dropdown_Sorted_elements {

	public static void main(String[] args) throws InterruptedException {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://online.apsrtcpass.in/counterstupass.do");
		WebElement district= driver.findElement(By.xpath("//select[@id='distId']"));
		driver.manage().window().maximize();
		Select sc = new Select(district);
		List org_list = new ArrayList();
		List<WebElement> options = sc.getOptions();
		
		for(WebElement e:options)
		{
			org_list.add(e.getText());
		}
		System.out.println("original list is :"+org_list);
		System.out.println();
		List temp_list = new ArrayList();
		temp_list = org_list;
		System.out.println("Before sorting temp list : "+temp_list);
		Collections.sort(temp_list);
		System.out.println("After sorting the listt :"+temp_list);
		if(org_list.equals(temp_list))
		{
			System.out.println("Drop down list is sorted");
		}
		else
		{
			System.out.println("Drop down list is not sorted");
		}
		driver.close();
	}

}
