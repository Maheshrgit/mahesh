package Basic_Programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Drop_Down_list {

public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://online.apsrtcpass.in/counterstupass.do");
		WebElement district= driver.findElement(By.xpath("//select[@id='distId']"));
		driver.manage().window().maximize();
		Select sc = new Select(district);
		Thread.sleep(2000);
		int a=sc.getOptions().size();
		System.out.println("number of districts are: "+a);
	/*
		 sc.selectByVisibleText("ANANTAPUR");
		Thread.sleep(3000);
		sc.selectByIndex(3);
		Thread.sleep(3000);
		*/
		sc.selectByVisibleText("KADAPA");
		Thread.sleep(3000);
		
		
		WebElement mandal= driver.findElement(By.xpath("//select[@id='man']"));
		Select sc1 = new Select(mandal);
		int b=sc1.getOptions().size();
		System.out.println("number of mandals are: "+b);
		sc1.selectByVisibleText("PULIVENDLA");
		Thread.sleep(3000);
		WebElement village= driver.findElement(By.xpath("//select[@id='vilId']"));
		Select sc2 = new Select(village);
		int c=sc2.getOptions().size();
		System.out.println("number of villages are: "+c);
		sc2.selectByValue("1");
		Thread.sleep(3000);
		WebElement address= driver.findElement(By.xpath("//textarea[@name='userProperties(addrhouseno)']"));
		address.sendKeys("3-5-525 , Bangarupeta");
		Thread.sleep(3000);
		driver.close();

	}


}
