package Basic_Programs;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Title_name {


	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.apsrtconline.in/oprs-web/");
		String Titlename = driver.getTitle();
		String reqtitle="APSRTC Official Website for Online Bus Ticket Booking- APSRTConline.in";
		System.out.println(Titlename);
		
		if(Titlename.equals(reqtitle))
		{
			System.out.println("pass");
		}
		else
		{
			System.out.println("fail");
		}
		
		
	//	driver.close();
	}

}

