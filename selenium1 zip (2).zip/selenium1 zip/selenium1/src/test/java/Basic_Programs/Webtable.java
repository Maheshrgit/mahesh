package Basic_Programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Webtable {

	public static void main(String[] args) {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://demo.guru99.com/test/web-table-element.php");
		int rows = driver.findElements(By.xpath("//table[@class='dataTable']//tr")).size();
		System.out.println(rows);
		int tablesize = driver.findElements(By.xpath("//table[@class='dataTable']//td")).size();
		System.out.println(tablesize);
		
		for(int i=2;i<rows;i++) // Rows
		{
			for(int j=1;j<=5;j++) // columns
			{
				//System.out.println(driver.findElement(By.xpath("//table[@class='dataTable']//tr["+i+"]//td["+j+"]")).getText()+" ");
				
				String a= (driver.findElement(By.xpath("//table[@class='dataTable']//tr["+i+"]//td["+j+"]")).getText()+" ");
				
				System.out.println(a);
			}
			System.out.println();
		}
		
	}

}
