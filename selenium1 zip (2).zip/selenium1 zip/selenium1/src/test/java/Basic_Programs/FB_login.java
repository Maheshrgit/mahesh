package Basic_Programs;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FB_login {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.facebook.com/");
		
		WebElement userID = driver.findElement(By.xpath("//input[@id='email']"));
		userID.sendKeys("8790549627");
		WebElement password = driver.findElement(By.xpath("//input[@id='pass']"));
		password.sendKeys("1234iliaz@");
	//	Thread.sleep(2000);
		WebElement view = driver.findElement(By.xpath("//div[@class='_9lsa']"));
	    view.click();
	//    Thread.sleep(2000);
	    WebElement login = driver.findElement(By.xpath("//Button[text()='Log In']"));
	    login.click();
//	    Thread.sleep(2000);
		


	}


}
