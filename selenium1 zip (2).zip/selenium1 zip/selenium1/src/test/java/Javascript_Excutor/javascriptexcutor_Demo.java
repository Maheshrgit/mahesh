package Javascript_Excutor;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class javascriptexcutor_Demo {

	public static void main(String[] args) throws IOException {
		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.twoplugs.com/");
		
		driver.manage().window().maximize();
		
	
		WebElement joinfree = driver.findElement(By.xpath("//span[text()='Join now for free']"));
		
		
		// Flashing the element
		javascript_util.flash(joinfree, driver);
		
		// Drawing border 
		javascript_util.drawBorder(joinfree, driver);
		
		// taking screenshott
		File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
		File trg = new File("C:\\Users\\krist\\OneDrive\\Pictures\\Screenshots\\twoplugs.png");
		FileUtils.copyFile(src, trg);
		
		// captuure tthe  tiitle oof page
		String title = javascript_util.getTitleByJS(driver);
		System.out.println(title);
		
		
		// click on some element
		WebElement btnlgn = driver.findElement(By.xpath("//a[@class='btn border']"));
		javascript_util.clickElementByJS(btnlgn, driver);
		
		driver.navigate().back();
	/*	// generate Alert popup
		javascript_util.generateAlert(driver, "You clicked on Login button"); */
		 
		// Refreshing the page
				javascript_util.RefreshBrowserByJS(driver);
		
		// Refreshing the page
		javascript_util.RefreshBrowserByJS(driver);
		
		
		// scroll down till we find element
		WebElement image = driver.findElement(By.xpath("//div[@class='img']"));
		javascript_util.scrollIntoView(image, driver);
		
		
		// scroll down page till end of the page
		javascript_util.scrollpageDown(driver);
	}
	}

	


