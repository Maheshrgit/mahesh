package Cookies;

import java.util.Set;

import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Cookie_test {

	public static void main(String[] args) {
	

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		
		Set <Cookie> cookies=driver.manage().getCookies();  // capture all the cookies from the browser
		System.out.println("size of cookies: "+cookies.size());  // print size of cookies

		for(Cookie cookie:cookies)  // read and print all the cookies
		{
			System.out.println(cookie.getName()+" : "+cookie.getValue());
		}
		
		/* i18n-prefs : INR
session-id-time : 2082787201l
ubid-acbin : 262-6205683-4131906
csm-hit : tb:s-6H3CGNH2KS086K0GDJ0Y|1648707601173&t:1648707601678&adb:adblk_no
session-id : 262-0300052-4825310
*/
		
		System.out.println();
		
		System.out.println(driver.manage().getCookieNamed("session-id-time"));
		
		System.out.println();
		
		Cookie cobj = new Cookie("mycookie123344","87905499627");
		driver.manage().addCookie(cobj);
		
		Set <Cookie> cookies1=driver.manage().getCookies();
		System.out.println("size of cookies: "+cookies1.size());
		for(Cookie cookie:cookies1)  // read and print all the cookies
		{
			System.out.println(cookie.getName()+" : "+cookie.getValue());
		}
		System.out.println();
		
		driver.manage().deleteCookie(cobj);
		
		Set <Cookie> cookies2=driver.manage().getCookies();
		System.out.println("size of cookies: "+cookies2.size());
		for(Cookie cookie:cookies2)  // read and print all the cookies
		{
			System.out.println(cookie.getName()+" : "+cookie.getValue());
		}
		
		System.out.println();
		driver.manage().deleteCookieNamed("ubid-acbin");
		
		Set <Cookie> cookies3=driver.manage().getCookies();
		System.out.println("size of cookies: "+cookies3.size());
		for(Cookie cookie:cookies3)  // read and print all the cookies
		{
			System.out.println(cookie.getName()+" : "+cookie.getValue());
		}
		
		driver.manage().deleteAllCookies();
System.out.println();
		
		driver.manage().deleteCookie(cobj);
		
		Set <Cookie> cookies4=driver.manage().getCookies();
		System.out.println("size of cookies: "+cookies4.size());
		for(Cookie cookie:cookies4)  // read and print all the cookies
		{
			System.out.println(cookie.getName()+" : "+cookie.getValue());
		}
		
		
		driver.close();
		
	}

}
