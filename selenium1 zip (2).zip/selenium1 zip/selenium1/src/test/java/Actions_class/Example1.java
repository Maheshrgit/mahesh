package Actions_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Example1 {

	

				
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver","C:\\Users\\krist\\chromedriver.exe");
			WebDriver driver = new ChromeDriver();
			driver.get("https://www.amazon.in/");
			 driver.manage().window().maximize();
			//Thread.sleep(4000);
			driver.findElement(By.id("twotabsearchtextbox")).sendKeys("Poco F1");  //By.xpath("//input[@id='twotabsearchtextbox']")
			//Thread.sleep(4000);
			driver.findElement(By.xpath("//input[@id='nav-search-submit-button']")).click();
		//	driver.findElement(By.xpath(("//input[@type='checkbox']")).click();
			//driver.findElement(By.linkText("Oppo")).click();
			//driver.navigate().to("https://www.facebook.com//");
		    //Thread.sleep(4000);
			//driver.navigate().back();
		//	driver.quit();
	}
		
}
