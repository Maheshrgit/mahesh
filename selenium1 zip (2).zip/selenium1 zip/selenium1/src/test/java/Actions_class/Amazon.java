package Actions_class;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Amazon {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		System.setProperty("webdriver.chrome.driver","C:\\Users\\krist\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.amazon.in/");
		
		
		WebElement userID = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
		userID.sendKeys("Mobile");
		WebElement submit = driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
		submit.click();
	}

}
