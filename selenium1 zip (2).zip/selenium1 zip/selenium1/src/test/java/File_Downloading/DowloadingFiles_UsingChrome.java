package File_Downloading;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DowloadingFiles_UsingChrome {

	public static void main(String[] args) {
	
		// intiating the driver 
		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		//maximize the windows
		driver.manage().window().maximize();
		
		
		// open the url of page
	/*	driver.get("http://demo.automationtesting.in/FileDownload.html");
		
		driver.findElement(By.xpath("//textarea[@id='textbox']")).sendKeys("Mahesh");
		driver.findElement(By.xpath("//button[@id='createTxt']")).click();
		
		driver.findElement(By.xpath("//a[@id='link-to-download']")).click(); */
		
		// 
		
		
		
		driver.get("http://demo.automationtesting.in/FileDownload.html");
		
		driver.findElement(By.xpath("//textarea[@id='pdfbox']")).sendKeys("Mahesh");
		driver.findElement(By.xpath("//button[@id='createPdf']")).click();
		
		driver.findElement(By.xpath("//a[@id='pdf-link-to-download']")).click();
		
		
		
		
	}

}