import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Broken_Links {

	public static void main(String[] args) throws InterruptedException, IOException {
		
		// initiating driver
		 System.setProperty("webdriver.chrome.driver","C:\\Users\\krist\\chromedriver.exe");
		// WebDriverManager.chromedriver().setup();
		 
		 WebDriver driver = new ChromeDriver();
		
		// WebDriverManager.firefoxdriver().setup();
		// WebDriver driver = new FirefoxDriver();
		
		//maximize the windows
		driver.manage().window().maximize();
		
		// implicit wait for 10 seconds
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		
		// open the url of page
		driver.get("https://demo.guru99.com/test/newtours/");
		
		// wait for 4 seconds
		Thread.sleep(4000);
		
		// capture links from a webpage
		List<WebElement> links = driver.findElements(By.tagName("a"));
		
		// number of links
		System.out.println(links.size());
		
		for(int i=0;i<links.size();i++)
		{
			// by using href attribute we can get URL of required link
			WebElement element = links.get(i);
			String url = element.getAttribute("href");
			
			URL link = new URL(url);
			
			// create connection using url object 'link'
			HttpURLConnection httpConn = (HttpURLConnection) link.openConnection();
			
			// wait time 2 seconds
			Thread.sleep(2000);
			
			// establish connection
			httpConn.connect();
			
			// return response if response code is above 400: broken link
			int rescode = httpConn.getResponseCode();
			
			if(rescode>=400)
			{
				System.out.println(url+" - "+" is broken link");
			}
			else
			{
				System.out.println(url+" - "+" is valid link");
			}
			
		}
		
		
		
		
	}

}
