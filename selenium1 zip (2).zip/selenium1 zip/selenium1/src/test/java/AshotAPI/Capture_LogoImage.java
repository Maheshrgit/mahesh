package AshotAPI;

import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;

public class Capture_LogoImage {

	public static void main(String[] args) throws IOException {

		System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/index.php/dashboard");	
		driver.manage().window().maximize();
		
		WebElement Logoimagge = driver.findElement(By.xpath("//div[@id='divLogo']"));
	
		
		Screenshot logoImageScreenshot = new AShot().takeScreenshot(driver, Logoimagge);
		ImageIO.write(logoImageScreenshot.getImage(), "png", new File("C:\\Users\\krist\\OneDrive\\Pictures\\Saved Pictures\\Orange.png"));
		
	File f=new File("C:\\\\Users\\\\krist\\\\OneDrive\\\\Pictures\\\\Saved Pictures\\\\Organge.png");
		
		if(f.exists())
		{
			System.out.println("Image File Captured");
		}
		else
		{
			System.out.println("Image File not Captured");
		}
	}

}
