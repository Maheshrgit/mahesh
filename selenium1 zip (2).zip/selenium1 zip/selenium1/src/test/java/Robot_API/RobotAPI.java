package Robot_API;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class RobotAPI {

public static void main(String[] args) throws AWTException {

System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
WebDriver driver = new ChromeDriver();
driver.manage().window().maximize();

driver.get("https://opensource-demo.orangehrmlive.com/index.php/admin/viewSystemUsers");
WebElement user = driver.findElement(By.xpath("//input[@id='txtUsername']"));
user.sendKeys("Admin");
WebElement pass = driver.findElement(By.xpath("//input[@id='txtPassword']"));
pass.sendKeys("admin123");
WebElement login = driver.findElement(By.xpath("//input[@id='btnLogin']"));
login.click();

driver.findElement(By.xpath("//input[@type='text'][1]")).sendKeys("Admin");
Robot robot = new Robot();

robot.keyPress(KeyEvent.VK_TAB);
robot.keyPress(KeyEvent.VK_DOWN);	
robot.keyPress(KeyEvent.VK_ENTER);

robot.keyPress(KeyEvent.VK_TAB);

driver.findElement(By.xpath("//input[@name='searchSystemUser[employeeName][empName]']")).sendKeys("Iliaz");

robot.keyPress(KeyEvent.VK_TAB);
robot.keyPress(KeyEvent.VK_DOWN);
robot.keyPress(KeyEvent.VK_ENTER);
robot.keyPress(KeyEvent.VK_TAB);
robot.keyPress(KeyEvent.VK_ENTER);


}



}