package assignment;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ReadDATA_FromEXCEL {

	public static void main(String[] args) throws IOException, InterruptedException {
		
System.setProperty("webdriver.chrome.driver","C:\\Users\\chromedriver.exe");
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://onedrive.live.com/?id=root&cid=F813B4384C789073");
		Thread.sleep(5000);
		
/*	WebElement userID = driver.findElement(By.xpath("//input[@type='email']"));
	userID.sendKeys("maheswar.r.reddy@gmail.com");
	WebElement Next = driver.findElement(By.xpath("//input[@type='submit']"));
	Next.click();
	WebElement Paswd = driver.findElement(By.xpath("//input[@name='passwd']"));
	Paswd.sendKeys("Mahesh8@128");
	WebElement Signin = driver.findElement(By.xpath("//input[@type='submit']"));
	Signin.click(); */
	
		FileInputStream file = new FileInputStream("Book1.xlsx");
		XSSFWorkbook workbook = new XSSFWorkbook(file);
		XSSFSheet sheet = workbook.getSheet("sheet1"); 
		// provide sheet name
		int rowcount = sheet.getLastRowNum();             // returns the last row number
		int colcount = sheet.getRow(0).getLastCellNum();            // returns last cell number
		
		for(int i=1;i<rowcount;i++)
		{
			XSSFRow current_row=sheet.getRow(i);      // focused on current row
			
			for(int j=0;j<colcount;j++)
			{
				String value = current_row.getCell(j).toString();
				System.out.print("  "+value+"  ");
			}
			System.out.println();
		}
		
		

	}

}
