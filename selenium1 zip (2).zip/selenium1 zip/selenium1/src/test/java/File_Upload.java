import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class File_Upload {

	public static void main(String[] args) {
		
		

		System.setProperty("webdriver.chrome.driver","C:\\work\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("http://demo.automationtesting.in/Register.html");	
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='imagesrc']")).click();
		String imagesFilepath = "Pictures";
		String inputFilepath="Pictures";
		
	}

}
