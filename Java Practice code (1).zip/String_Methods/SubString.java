package String_Methods;

public class SubString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

String s3="WELCOME";



System.out.println(s3.substring(0,3));                   //WEL

System.out.println(s3.substring(2,5));                   // LCO

System.out.println(s3.substring(4,7));                   // OME

	}

}
