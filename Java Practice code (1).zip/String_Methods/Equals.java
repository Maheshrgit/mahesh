package String_Methods;

public class Equals {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

String s3="WELCOME";
String s4="welcome";

System.out.println(s3.equals(s4));                        // false

	}
}
