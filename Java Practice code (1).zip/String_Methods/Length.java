package String_Methods;

public class Length {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="Welcome";
		System.out.println(s.length());      // 7

	}

}
