package String_Methods;

public class Contains {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

String s3="WELCOME";



System.out.println(s3.contains("WEL"));                  // true

System.out.println(s3.contains("abc"));                  // false

	}
}
