package String_Methods;

public class Replace {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String s3="WELCOME";
		

		System.out.println(s3.replace("WEL","ABC"));            // ABCCOME

		System.out.println(s3.replace("OME","XYZ"));            // WELCXYZ

	}
}
