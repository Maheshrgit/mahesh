package String_Methods;

public class Concat {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s1="Welcome to";
		String s2="training";

		System.out.println(s1.concat(s2));                          // Welcome totraining

		System.out.println(s1+s2);                                  // Welcome totraining

		System.out.println("Welcome to".concat(s2));               // Welcome totraining

		System.out.println(s1.concat("training"));                 // Welcome totraining

		System.out.println(s1.concat(" "+s2));                     // Welcome to training

	}

}
