package LOOPS;

public class For_loop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		for(i=0;i<=100;i++)
		{
			System.out.println(i);
			}
	}
}
