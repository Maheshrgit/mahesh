package pack_2;

import pack_1.A;

public class B extends A
{

	
	public static void main(String[] args) {
		
		A a=new A();
		
	//	a.i=20;  // canot access because it is default(access within package only)
	//	a.m1();  // canot access because it is default(access within package only)
		
		a.j=30;  // can access because it is public
		a.m2();  // can access because it is public
		
	//  a.k=20;    // canot access because it is private variable
	//  a.m3();    // canot access because it is private method
		
		B b= new B(); 
		b.x=50;         // can acceess because it is protected( inherited the class)
		b.m4();       // can acceess because it is protected( inherited the class)
	}

}
  

