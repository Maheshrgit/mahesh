package Inheritance;

class Bank
{
	int getRateOfInterest()
	{
		return 0;
	}
}

class SBI extends Bank
{
	int getRateOfInterest()
		{
			return 10;
		}
	}


class ICICI extends Bank
{
	int getRateOfInterest()
	{
		return 15;
	}
}

class Axis extends Bank
{
	int getRateOfInterest()
	{
		return 12;
	}
}



public class Method_Overriding {

	public static void main(String[] args) {
	
		SBI sbi = new SBI();
		System.out.println(sbi.getRateOfInterest());
		
		ICICI icici = new ICICI();
		System.out.println(icici.getRateOfInterest());
		
		Axis axis = new Axis();
		System.out.println(axis.getRateOfInterest());
		
	}

}
