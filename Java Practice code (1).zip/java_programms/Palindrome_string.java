package java_programms;

import java.util.Scanner;

public class Palindrome_string {

public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a String");
		String str = sc.next();
		
		String org_str=str;
		

	StringBuffer rev;
	StringBuffer sb = new StringBuffer(str);
	rev=sb.reverse();
      System.out.println("reverse string is "+rev);
		
		if(org_str.contentEquals(rev))
		{
			System.out.println("this is a palindrome string");
		}
		else
		{
			System.out.println("this is not a palindrome string");
		}
}
}
