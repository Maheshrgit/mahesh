package java_programms;

public class swapping_TWO_numbers {

	public static void main(String[] args) {
		
		int a=10;
		int b=20;
		
		System.out.println("Before swapping the numbers are: "+a+ " "+b);
		
		
		// using third varriable
		
		/*
		int c;
		c=b;
		b=a;
		a=c;
		*/ 
		
		
		// using algorithm
		
		/*
		a=a+b;
		b=a-b;
		a=a-b;
		*/
		
		a=a*b;
		b=a/b;
		a=a/b;
		
		System.out.println("after  swapping the numbers are: "+a+ " "+b);
		
	}
}
