package java_programms;

import java.util.Scanner;

public class Reverse_string {

public static void main(String[] args) {
	
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a String");
		String str = sc.next();
		String rev= " ";
		
		
		
		// using string concatination operator 
		
		/* 
		
	int len = str.length();
	
	for(int i=len-1;i>=0;i--)
	{
		rev = rev+str.charAt(i); 
	}
		*/
		
		
		// using character array
		
		char a[] = str.toCharArray();
		
		int len = a.length;
		for(int i=len-1;i>=0;i--)
		{
			rev = rev+a[i];
		}
		
		
		// using Stringbuffer
		
		/*
		StringBuffer rev;
		StringBuffer sb = new StringBuffer(str);
		rev=sb.reverse();
		*/
		
		
		// using StringBilder
		
		 /* 
		  * StringBuilder rev;
		StringBuilder sbl=new StringBuilder();
		rev= sbl.append(str);
		sbl.reverse();
		
		*/
		
		System.out.println("reverse string is "+rev);
	}
}
