package java_programms;

import java.util.Scanner;

public class Largestof_3numbers {

	public static void main(String[] args) {
		
		 Scanner sc= new Scanner(System.in);
			System.out.println("Enter first Number");
			int a = sc.nextInt();
			System.out.println("Enter second Number");
			int b = sc.nextInt();
			System.out.println("Enter third Number");
			int c = sc.nextInt();
		
		
		if(a>b && a>c)
		{
			System.out.println(a+" is the largest number");
		}
		else if(b>a && b>c)
		{
			System.out.println(b+" is the largest number");
		}
		else
		{
			System.out.println(c+" is the largest number");	
		}
		
		
	}
}
