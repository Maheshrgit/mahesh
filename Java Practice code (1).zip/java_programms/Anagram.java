package java_programms;


import java.util.Arrays;
import java.util.Scanner;

public class Anagram {

	public static void main(String[] args) {
		
		//Anagram1();
		Anagram2();
		
	}
	
		public static void Anagram1()
		{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter first String: ");
		String x=sc.next();
		Scanner sc1 = new Scanner(System.in);
		System.out.println("Enter second String:");
		String y=sc1.next();
		
		char a[] = x.toCharArray();
		char b[] = y.toCharArray();
		
		Arrays.sort(a);
		Arrays.sort(b);
		
		System.out.println(a);
		System.out.println(b);
		
		Boolean result = Arrays.equals(a, b);
		
		if(result == true)
		{
			System.out.println("Given both strings are  Anagram");
		}
		else
		{
			System.out.println("Given both strings are not  Anagram");
		}
		
	}

		
		public static void Anagram2()
		{
		String x="he is iliaz";
		String y="Iliaz he is";
		
		x=x.replace(" ", "");
		y=y.replace(" ", "");
		
		x=x.toLowerCase();
		y=y.toLowerCase();
		
		char a[] = x.toCharArray();
		char b[] = y.toCharArray();
		
		Arrays.sort(a);
		Arrays.sort(b);
		
		System.out.println(a);
		System.out.println(b);
		
		Boolean result = Arrays.equals(a, b);
		
		if(result == true)
		{
			System.out.println("Given both strings are  Anagram");
		}
		else
		{
			System.out.println("Given both strings are not  Anagram");
		}
		
	}

}
