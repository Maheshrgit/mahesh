package java_programms;

import java.util.Scanner;

public class reverse_number {

public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter a Number");
		int num = sc.nextInt();
		
	// using algorithm	
		
		/*
		 int rev=0;
		
		while(num!=0)
		{
			rev=rev*10+num%10;
			num=num/10;
		}
		 */
		
		// using stringBuffer
		
		/* 
		 StringBuffer rev;
		
		StringBuffer sb= new StringBuffer(String.valueOf(num));
		rev= sb.reverse();
		
		*/
		
		// using Stringbuilder
		
		StringBuilder rev;
		StringBuilder sbl=new StringBuilder();
		rev= sbl.append(num);
		sbl.reverse();
		
		
		
		
		
		System.out.println("reverse number is "+rev);
		
		
		
		
	}
}
