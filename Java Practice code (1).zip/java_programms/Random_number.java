package java_programms;

import java.util.Random;

public class Random_number {

public static void main(String[] args) {
		
		// Approach 1
		
		
		Random rand = new Random();
		int rand_int = rand.nextInt(999);
		System.out.println(rand_int);
		
		double rand_dbl= rand.nextDouble(10);
		System.out.println(rand_dbl);
	
		
		
		// Approach 2
		
		
		//System.out.println(Math.random());
		
		
		
		
	}
}
