package Arrays;

public class Example2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]=new int[4];
		a[0]=10;
		a[1]=20;
		a[2]=30;
		a[3]=40;
		for(int i:a)
		{
			System.out.println(i);
		} 
	}

}


