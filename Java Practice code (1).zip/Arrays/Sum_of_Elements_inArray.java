package Arrays;

public class Sum_of_Elements_inArray {

	public static void main(String[] args) {
		
		int a[]={100,200,300,400,500,600,700,800,1000};
		int sum=0;
		for(int i:a)
		{
		System.out.println(i);
		sum=sum+i;
		}
		System.out.println(sum);
	}

}

