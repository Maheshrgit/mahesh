package Arrays;

public class Two_Dimenssional_array {

	public static void main(String[] args) {
		int a[][]= {{10,20},{30,40},{50,60}};

			for(int i[]:a)
			{
				for(int j:i)
				{
					System.out.print(j+" ");
				}
			System.out.println();
			}
		}

	}

	


