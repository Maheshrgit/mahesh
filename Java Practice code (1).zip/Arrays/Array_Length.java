package Arrays;

public class Array_Length {

	public static void main(String[] args) {
		
		int a[]= {100,200,300,400,500};
		System.out.println(a.length);
		
	
	}
}
