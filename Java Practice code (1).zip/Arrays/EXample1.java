package Arrays;

public class EXample1 {

	public static void main(String[] args) {
		
		int a[]= {100,200,300,400,500};
		for(int i:a)
		{
			System.out.println(i);
			
		}
	}

}
