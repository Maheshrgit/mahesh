package Arrays;

public class Two_Dimenssional_array_2 {

	public static void main(String[] args) {
		
int a[][]=new int[5][3];
a[0][0]=10;
a[0][1]=20;
a[0][2]=30;
a[1][0]=40;
a[1][1]=50;
a[1][2]=60;
a[2][0]=70;
a[2][1]=80;
a[2][2]=90;
a[3][0]=100;
a[3][1]=110;
a[3][2]=120;
a[4][0]=130;
a[4][1]=140;
a[4][2]=150;
for(int i[]:a)
{
	for(int j:i)
	{
		System.out.print(j+" ");
	}
	System.out.println();
}
	}

}
