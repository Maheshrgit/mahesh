package Arrays;

public class Object_Array {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object a[]=new Object[7];
		a[0]="WISH";
		a[1]="YOU";
		a[2]='A';
		a[3]="HAPPY";
		a[4]="NEW";
		a[5]="YEAR";
		a[6]=2022;
		for(Object i:a)
		{
		System.out.print(i+"  ");

		}
		

	}
}
