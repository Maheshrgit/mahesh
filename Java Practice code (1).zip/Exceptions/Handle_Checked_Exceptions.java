package Exceptions;

public class Handle_Checked_Exceptions {

	public static void main(String[] args) throws InterruptedException {
	
		System.out.println("Prohram is started");
		System.out.println("Prohram is Progress");
		
		// handling InterruptedException (Checked Exception) by using try_catch block
		// try_catch block will excute Checked exceptions as well as Unchecked exceptions
		// try_catch block will use only in statemeent only ( not method level)
		try
		{
			Thread.sleep(2000);        // InterruptedException
		}
		catch(InterruptedException e)
		{
			System.out.println(e.getMessage());
		}
		
		
		// handling InterruptedException (Checked Exception) by using throws keyword
		// throws keyword  will excute Checked exceptions only (not Unchecked exceptions )
		// throws keyword will use in method level only (not statement leveel )
		
		Thread.sleep(2000);
		
		System.out.println("Prohram is Completed");
		System.out.println("Prohram is exited");

	}

}
