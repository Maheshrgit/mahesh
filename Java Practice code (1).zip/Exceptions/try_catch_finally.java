package Exceptions;

public class try_catch_finally {

	public static void main(String[] args) {
	
		System.out.println("Program is started");
		
		// try_catch block will excute Unchecked exceptions as well as Checked exceptions
		// try_catch block will use only in statemeent only ( not method level)

		
		// case 1 -- exception occurs , catch block excuted , finally block also excuted
		int arr[] = new int[5];          	
		try
		{
			arr[10]=100;	  // ArrayIndexOutOfBoundException
		}	
		catch( ArrayIndexOutOfBoundsException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("this is finally block");
		}
		
		
		// case 2 -- exception not occurs , catch block ignored , finally block  excuted
		String s="iliaz";
		try 
		{
		System.out.println(s.length());   // NullPointerException
		}
		catch(NullPointerException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("this is finally block");
		}
		
		
		// case 3 -- exception occurs , catch block not excuted , finally block  excuted
		int a=20;
		try
		{
			System.out.println(a/0);  // ArthemeticException
		}
		catch(NullPointerException e)
		{
			System.out.println(e.getMessage());
		}
		finally
		{
			System.out.println("this is finally block");
		}
		
		
	}

}
