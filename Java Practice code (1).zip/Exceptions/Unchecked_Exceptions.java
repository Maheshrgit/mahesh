package Exceptions;

public class Unchecked_Exceptions {

	public static void main(String[] args) {
	
		int a=20;
		 System.out.println(a/0);         // ArthemeticException
		
		String s=null;
		System.out.println(s.length());   // NullPointerException
		
		String st="iliaz";
		int i=Integer.parseInt(st);
		System.out.println(i);          //  NumberFormatException
		
		int arr[] = new int[5];
		arr[10]=100;                    // ArrayIndexOfBoundException
		
	}

}
