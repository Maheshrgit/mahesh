package OOPS;

public class This_keyword {

	public static void main(String[] args) {
		
		This_keyword th = new This_keyword();
		th.sum(10,20);

	}
	
	int a;
	int b;
	
	void sum(int a,int b)
	{
		 this.a=a;
		 this.b=b;
		System.out.println(a+b);
	}

}
