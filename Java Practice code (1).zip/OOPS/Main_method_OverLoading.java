package OOPS;

public class Main_method_OverLoading {

	public static void main(String[] args)
	{
	// code
	}

	public static void main() 
	{
		// code
	}
	public static void main(int a,int b)
	{
		// code
	}
	
}
