package OOPS;

public class Static_Example {

	public static void main(String[] args)
	{
		b=100;
		m1();
		
		Static_Example st=new Static_Example();
		
		 st.m2();
		System.out.println(st.b=200);
		
		
		st.m3();
		
	}
	
	int a;
	static int b;
	
	static void m1()
	{
		
		System.out.println("this is m1 : static method");
		System.out.println(b);
	}
	
	void m2()
	{
		a=10;
		System.out.println("this is m2 : non-static method");
		System.out.println(a);
		System.out.println(b);
	}
	
	void m3()
	{
		a=10;
		b=20;
		
		m1();
		m2();
	}

}
