package OOPS;

public class Calculation {

	int a;
	int b;
	void sum()
	{
		System.out.println(a+b);
		
	}
	
	void sum1(int x,int y)
	{
		 a=x;
		b=y;
		System.out.println(a+b);	
	}
	
	int sum2()
	{
		return(a+b);
	}

	
	public static void main(String[] args) {
	
Calculation cal=new Calculation();
cal.a=100;
cal.b=200;
cal.sum();

cal.sum1(100, 200);

int r=cal.sum2();
System.out.println(r);

	}

}








