package OOPS;

public class Constructor_OverLoading {

	public static void main(String[] args) {
		
	//	 Constructor_OverLoading co = new Constructor_OverLoading();  // call the first onstructor
	//   Constructor_OverLoading co = new Constructor_OverLoading(10,20);  // call the second constructor
	//	 Constructor_OverLoading co = new Constructor_OverLoading(10,20.5);  // call the third constructor
	//	 Constructor_OverLoading co = new Constructor_OverLoading(10,20,30.5); // call the fourth constructor
		 Constructor_OverLoading co = new Constructor_OverLoading(10,20.5,30); // call he fifth constructor
		 
		co.display();

	}

	int a=0;;
	int b=0;
	double c=0;
	
	Constructor_OverLoading()  // first
	{
		a=10;
		b=20;
		c=20.5;
	}
	
	Constructor_OverLoading(int x,int y)   // second
	{
		a=x;
		b=y;
	}
	
	Constructor_OverLoading(int x,double y)  // third
	{
		a=x;
		c=y;
	}
	
	Constructor_OverLoading(int x,int y,double z)  // fourth
	{
		a=x;
		b=y;
		c=z;
	}
	
	Constructor_OverLoading(int x,double y,int z)  // fourth
	{
		a=x;
		b=z;
		c=y;
	}
	
	void display()
	{
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	
}
