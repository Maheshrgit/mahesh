package OOPS;

public class Employee {

	int empid;
	String empname;
	int salary;
	int deptno;
	
	void setdata(int id,String name,int sal,int dno)
	{
		empid=id;
		empname=name;
		salary=sal;
		deptno=dno;
	}
		
		
	void display()
	{
		System.out.println(empid);
		System.out.println(empname);
		System.out.println(salary);
		System.out.println(deptno);
	}
	public static void main(String args[])
	{
		
	Employee emp1=new Employee();
	emp1.setdata(101,"iliaz",70000,10);
	emp1.display();
	
	

	Employee  emp2=new Employee ();
	emp2.setdata(102,"raj",60000,20);
	emp2.display();
	
	}
		  /* employee emp1=new employee(101,"iliaz",70000,10);
		emp1.display();
		
		employee emp2=new employee(102,"raj",60000,20);
		emp2.display();
	}|
		
	 /*EMPLOYEE emp1=new EMPLOYEE();
	emp1.empid=101;
	emp1.empname="iliaz";
	emp1.salary=70000;
	emp1.deptno=10;
	emp1.display();
	
	EMPLOYEE emp2=new EMPLOYEE();
	emp2.empid=102;
	emp2.empname="raj";
	emp2.salary=60000;
	emp2.deptno=20;
	emp2.display();
	*/
	}

