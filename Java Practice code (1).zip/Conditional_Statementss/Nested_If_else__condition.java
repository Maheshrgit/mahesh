package Conditional_Statementss;

public class Nested_If_else__condition {

public static void main(String[] args) {
		
		// nested if else condition
		
				int a=2;
				if(a==1)
				{
					System.out.println("SUNDAY");
				}
				else if(a==2)
				{
					System.out.println("MONDAY");
				}
				else if(a==3)
				{
					System.out.println("TUESDAY");
				}
				else if(a==4)
				{
					System.out.println("WEDNESDAY");
				}
				else if(a==5)
				{
					System.out.println("THURSDAY");
				}
				else if(a==6)
				{
					System.out.println("FRIDAY");
				}
				else
				{
					System.out.println("SATURDAY");
				}
	}
}
