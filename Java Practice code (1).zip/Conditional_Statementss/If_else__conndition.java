package Conditional_Statementss;

public class If_else__conndition {

	public static void main(String[] args) {
		
		int age=21;
				
		//if else condition

				if(age>=21)
				{
					System.out.println("not eligible to marriage");
				}
				else
				{
					System.out.println("elegible to marriage");
				}
			}

}
