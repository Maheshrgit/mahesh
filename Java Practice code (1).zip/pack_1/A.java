package pack_1;

public class A {

	int i=10;            // default
	public int j=20;     // public
	private int k=30;    // private
	protected int x=40;  // protecteed
	
	void m1()
	{
		System.out.println(i);
	}
	
	public void m2()
	{
		System.out.println(j);
	}
	
	private void m3()
	{
		System.out.println(k);
	}
	
	protected void m4()
	{
		System.out.println(x);
	}
	
}
