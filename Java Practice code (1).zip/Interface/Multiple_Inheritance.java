package Interface;

interface A
{
	int a=10;
	void display();
}

interface B
{
	int b=20;
	void show();
}

public class Multiple_Inheritance implements A,B
{
 public void display()
 {
	 System.out.println(a);
 }
 public void show()
 {
	 System.out.println(b);
 }
 
	public static void main(String[] args) 
	{
		Multiple_Inheritance mi = new Multiple_Inheritance();
		mi.display();
		mi.show();

	}

}
