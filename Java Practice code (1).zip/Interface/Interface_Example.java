package Interface;


interface Testint
{
	int a=10;        // by default variable is static and final
	void display();  // by default methods are abstract (only definition no body)
}

public class Interface_Example implements Testint
{

	public void display()
	{
		System.out.println(a);
	}
	
	public static void main(String[] args) {
	
		Testint obj = new  Interface_Example();
		obj.display();
	}

}
