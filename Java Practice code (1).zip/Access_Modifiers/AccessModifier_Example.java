package Access_Modifiers;

class A
{

	private int a=10;   // private variable
	int b=20;           // default variable
	
	private void m1()    // private method
	{
		System.out.println(a);
	}
	
	void m2()
	{
		System.out.println(b);
	}
}

public class AccessModifier_Example 
{

	public static void main(String[] args) {
		
		A a1 = new A();
		// a1.a=20;    // canot access because it is private variable
		// a1.m1();    // canot access because it is private method
		
		a1.m2();
	
	}

}
