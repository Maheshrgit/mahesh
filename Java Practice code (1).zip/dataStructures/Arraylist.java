package dataStructures;

import java.util.ArrayList;

public class Arraylist {


	public static void main(String[] args) {
		
		ArrayList<String> list = new ArrayList<String>();
		
		// adding elements to arraylist
		list.add("Raju");
		list.add("Rani");
		list.add("Ramu");
		list.add("Rahul");
		
		System.out.println(list.size());  // return number of eeleemeents in Arraylist
		for(String s:list)     // reading elements from arraylist
		{
			System.out.println(s);
		}
		
		
	}

}
