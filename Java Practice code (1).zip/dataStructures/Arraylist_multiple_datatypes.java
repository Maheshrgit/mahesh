package dataStructures;

import java.util.ArrayList;

public class Arraylist_multiple_datatypes {

	public static void main(String[] args) {
	
		ArrayList al = new ArrayList();
		
		System.out.println("Number of elements in Arraylist are:" + al.size());
		
		// adding elements to arraylist
		al.add("welcome");
		al.add(10);
		al.add(10.456);
		al.add('c');
		
		System.out.println("Elements in Arraylist are:" + al);
		
		al.add(2, " training");
		al.add(5, "205");
		
		System.out.println("Number of elements in Arraylist after adding are:" + al.size());
		System.out.println("Elements in Arraylist after adding are:" + al);
		
		al.remove(3);
		System.out.println("Number of elements in Arraylist after removing are:" + al.size());
		System.out.println("Elements in Arraylist after removing are:" + al);
		
	}
	
	

}
