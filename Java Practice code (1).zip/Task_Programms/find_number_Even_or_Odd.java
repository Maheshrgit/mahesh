package Task_Programms;

public class find_number_Even_or_Odd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
if(a%2==0)
{
	System.out.println("a =  " +a+ " is even number");
}
else 
{
	System.out.println("a =  " +a+ " is odd number");
	}
	}
}
