package Task_Programms;

public class Print_Odd_Numberrs {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		
		// FOR loop
		for(i=1;i<=100;i=i+2)
		{
			System.out.println(i);
			}
		
		// while loop
		while(i<=12)
		{
		System.out.println(i);
		i=i+2;
		}
		
		
		// do-while loop
		do
		{
		System.out.println(i);
		i=i+2;
		}
		while(i<=12);
	}

}
