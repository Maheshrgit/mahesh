package Task_Programms;

public class Print_Even_numbers {

	public static void main(String[] args) {
		int i=0;
		
		// for loop
		for(i=0;i<=30;i=i+2)
		{
			System.out.println(i);
		}
		
		// while loop
		while(i<=30)
		{
		System.out.println(i);
		i=i+2;
		}

		// do-while loop
		do
		{
		System.out.println(i);
		i=i+2;
		}
		while(i<=12);
		
		
	}

}
