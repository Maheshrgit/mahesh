package Task_Programms;

public class Fizz_Buzz_Programme {

	public static void main(String[] args) {
		int i=24;
		if(i%3==0)
		{
			System.out.println("This is a FIZZ programme");
			
		}
		else if(i%5==0)
		{
			System.out.println("This is a BUZZ programme");
		}
		else if(i%3==0 && i%5==0)
		{
			System.out.println("This is a FIZZ BUZZ programme");
		}
			
		}
}
