package Task_Programms;

public class Find_LargestNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=20;
int c=30;
if((a>b)&&(b>c))
{
	System.out.println("a is largest number");
}
else if((b>a)&&(a>c))
{
	System.out.println("b is largest number");	
}
else 
{
	System.out.println("c is largest number");

}
	}

}
