package Operators;

public class Assignment_Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int a=10;
int b=20;
//assignment operators

int c;
c=a;

System.out.println(c);              // 10

c=b;
System.out.println(c);              // 20

c=100;
System.out.println(c);               // 100

c++;
System.out.println(c);                // 101

c=c+5;
System.out.println(c);                // 106

c--;
System.out.println(c);                // 105

c=c-6;
System.out.println(c);                // 99

c+=10;
System.out.println(c);               // 109

c-=20;
System.out.println(c);               // 89

c*=2;
System.out.println(c);                 // 178

c/=1;
System.out.println(c);                  // 178
	}

}
