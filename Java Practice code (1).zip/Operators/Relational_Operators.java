package Operators;

public class Relational_Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
	
	//relational operators
		
		System.out.println(a<b);          // true
		System.out.println(a>b);          // false
		System.out.println(a<=b);         // true
		System.out.println(a>=b);         // false
		System.out.println(a!=b);          // true
		System.out.println(a==b);         // false
		
	

	}
}
