package Operators;

public class Arthmetic_Operators {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		int b=20;
		
		//arthemetic oprerators
		
		System.out.println(a+b);        // 30
		System.out.println(a-b);        //  -10
		System.out.println(a*b);        // 200
		System.out.println(a/b);        // 0     
		System.out.println(a%b);        // 10
	}

}
